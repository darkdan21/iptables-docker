#!/bin/bash
./reset.sh
iptables -A INPUT -p tcp --dport 80 -j REJECT --reject-with tcp-reset
